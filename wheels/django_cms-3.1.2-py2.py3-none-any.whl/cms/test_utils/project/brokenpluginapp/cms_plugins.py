import nonexistingmodule  # nopyflakes
