# -*- coding: utf-8 -*-
__version__ = "2.6.0"
default_app_config = 'djangocms_text_ckeditor.apps.TextCkeditorConfig'
